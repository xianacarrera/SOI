El makefile incluido permite compilar todos los entregables de forma automática con
la regla por defecto ("make"). Asimismo, se pueden limpiar los archivos .o mediante
"make clean" y limpiar tanto archivos .o como ejecutables con "make cleanall".
